These files contain the yearly measures for BOD pollution in African countries.
The data has been extracted from a simulation model (WaterQual from the WaterGAP 3 framework)
The data is originally distributed across cells and have been aggregated on the country level.
Aggregation methods used are minimum, quantiles, maximum, mean and those adjusted vor the country size.