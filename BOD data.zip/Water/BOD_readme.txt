The files in this folder contain yearly measures for BOD pollution in African countries. The data has been used in the paper 
"An augmented Environmental Kuznets Curve and a new measure of water pollution: an investigation of water pollution in Africa" 
by Kupzig et al. (2024) [DOI: 10.1007/s43832-024-00177-8]. 

The data has been extracted from a simulation model on global water quality, i.e., the WaterQual model from the WaterGAP3 framework. 
The data is originally distributed across cells and have been aggregated on the country level by our co-author Jenny Kupzig. Aggregation 
methods found in the data provided in this folder are minimum, various quantiles, maximum, mean and these measures adjusted for the country size.

We are grateful to Prof. Dr. Martina Flörke and Dr. Jaime Rivera for providing the data from the model. More information on the data and the model 
can be found in the Appendix of Kupzig et al. (2024) and cited sources on the WaterGAP 3 framework. 
